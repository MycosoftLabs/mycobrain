# MycoBrain Firmware Recovery Notes — Jetson-Myco-1

_Date: 2026-03-23_

## Summary

The attached ESP32-S3 MycoBrain board was recoverable and remotely flashable from Jetson-Myco-1, but multiple firmware/build configurations in this repo produced a boot loop on the actual hardware.

A stable recovery state was achieved using:

- **raw esptool flashing**
- **flash mode: `dio`**
- **flash size: `8MB`**
- **recovery firmware with minimal runtime assumptions**

## What failed

### 1. MDP production firmware (`MycoBrain_SideA_MDP`)

Observed behavior after successful flash:
- upload succeeded
- board reset successfully
- board entered repeated ESP-ROM boot loop
- no stable CLI / application-level output was available

Implication:
- successful flash did **not** imply successful runtime on actual hardware
- current Side A MDP profile is not yet safe as the default bring-up target for this board

### 2. Generic recovery/minimal firmware with default DevKit assumptions

Observed behavior:
- compiled cleanly
- flashed cleanly
- still boot-looped on the hardware

Implication:
- this is not just an application logic bug
- boot/flash configuration matters for this board

### 3. PlatformIO-managed upload path intermittency

Observed behavior:
- some uploads failed with serial exceptions during handoff
- root cause included stale serial-holder processes and generally fragile USB serial state while the board was unstable

## What worked

A stable runtime was restored with the following approach:

1. Build a minimal recovery firmware
2. Use **8MB flash assumption**
3. Use **`dio` flash mode**
4. Flash using **raw `esptool.py write_flash`** instead of relying only on the higher-level upload path

Stable post-flash observations:
- board remained up
- periodic heartbeats appeared on serial
- command responses worked

Verified examples:
- `OK: heartbeat ms=12033`
- `OK: ping`
- `OK: status ms=19534`

## Key engineering conclusion

For this physical board, the repo currently contains firmware/config combinations that are **not safe default bring-up targets**.

The project needs:
- a documented **known-good board profile**
- a documented **stable recovery path**
- clear separation between:
  - production-intended firmware
  - experimental firmware
  - board recovery / bring-up firmware

## Recommended repo maturity changes

1. Add a dedicated `recovery/` area for stable bring-up firmware
2. Mark current Side A MDP as **not default-safe** until validated on real hardware
3. Document board-specific flash assumptions (at minimum: `dio`, `8MB` for the tested board)
4. Create a bring-up checklist for future devs and agents
5. Stop assuming generic ESP32-S3 DevKit defaults are correct for every MycoBrain board revision

## Immediate next steps for project completion

1. Keep the board on the stable recovery image for bring-up and sensor day
2. Add LED/buzzer/I2C scan to the stable recovery path if needed
3. Reintroduce richer firmware features incrementally from a known-good base
4. Validate each firmware profile against real hardware before calling it production-ready

## Recovery artifacts created in workspace

These were created outside the imported repo during live recovery work and should be copied/adapted into the project as needed:

- `recovery/mycobrain-sidea-minimal/`
- `recovery/mycobrain-sidea-minimal-dio/`
- `recovery/mycobrain-sidea-minimal-no-usb/`

## Important note for future agents/devs

Do **not** assume that a successful flash means the firmware is working.
Always verify:
- stable boot
- serial heartbeat
- basic command handling
- repeated uptime growth without reset

That verification saved this bring-up.
