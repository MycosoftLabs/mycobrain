# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** B
- **What to call them:** B
- **Pronouns:** _(optional)_
- **Timezone:** America/Los_Angeles
- **Notes:** Part of Mycosoft. Building environmental intelligence / “the neuralink for earth.”

## Context

- Working toward an MVP with Jetson + custom ESP32 board + sensors.
- Wants a workspace for docs, checklists, and reusable skills for replicated deployments.
- Wants skills added in the right native OpenClaw system locations, while keeping deployment-specific docs in the workspace.
- Envisions additional connectivity beyond USB-C, including an eventual SIM-based board/connection path.
- Team identity: Mycosoft.

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
