# MycoBrain Workspace — Jetson-Myco-1

Edge compute and operator station for [MycoBrain](imports/mycobrain-main/README.md) environmental sensor boards.

## What's Here

| Directory | Purpose |
|-----------|---------|
| `recovery/` | PlatformIO firmware variants for ESP32-S3 bring-up and operator use |
| `tools/` | Jetson-hosted Node.js services (telemetry hub, operator UI, publisher) |
| `imports/mycobrain-main/` | Imported upstream MycoBrain repo (production firmware, docs, deploy scripts) |
| `docs/mycobrain/` | Working plans, schemas, and architecture notes |
| `memory/` | Session memory and daily logs |

## Architecture

```
ESP32-S3 (Side A)            Jetson Nano Orin
┌──────────────────┐         ┌─────────────────────────────────────┐
│ BME680/688 × 2   │  USB    │  Telemetry Hub (:8788)              │
│ NeoPixel, Buzzer  ├────────►  owns /dev/ttyACM0                  │
│ MOSFETs, Analog   │ Serial │  parses JSON lines, serves HTTP API │
│                    ◄────────┤                                     │
│ JSON telemetry    │  cmds   │  Operator UI (:8787)                │
│ every 2s          │         │  proxies hub API, dark-themed web   │
└──────────────────┘         │                                     │
                              │  Publisher (:8789)                  │
                              │  normalizes → schema v1 → queue     │
                              │  upstream POST when configured      │
                              └─────────────────────────────────────┘
```

## Quick Start

**Operator UI** (requires hub running first):
```bash
cd tools/mycobrain-telemetry-hub && npm start &
cd tools/mycobrain-ui && npm start &
# Open http://<jetson-ip>:8787
```

**Publisher** (normalizes and queues telemetry):
```bash
cd tools/mycobrain-publisher && npm start
# To enable upstream delivery:
# MYCOBRAIN_UPSTREAM_URL=https://api.example.com/ingest npm start
```

**Build firmware** (requires PlatformIO):
```bash
cd recovery/mycobrain-sidea-minimal-dio && pio run
# Flash: pio run -t upload
```

## Hardware

- **MCU:** ESP32-S3 (8MB flash, DIO)
- **Sensors:** BME680/688 on I2C — AMB at 0x77, ENV at 0x76
- **I2C:** SDA=GPIO5, SCL=GPIO4
- **Actuators:** NeoPixel (GPIO15), Buzzer (GPIO16), MOSFETs (GPIO12–14)
- **Serial:** USB CDC, 115200 baud, `/dev/ttyACM0`

## Development Tracks

- **Operator Track:** stable recovery firmware + local tools for bring-up and diagnostics
- **Production Track:** MDP-framed protocol, dual BME688/BSEC2, Side A ↔ Side B ↔ Jetson chain

See [docs/mycobrain/TRACK_STRATEGY.md](docs/mycobrain/TRACK_STRATEGY.md) for details.
