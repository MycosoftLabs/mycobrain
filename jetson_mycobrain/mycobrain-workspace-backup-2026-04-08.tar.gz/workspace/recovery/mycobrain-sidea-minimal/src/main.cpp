#include <Arduino.h>

static const int NEOPIXEL_PIN = 15;
static const int BUZZER_PIN = 16;
static const uint32_t SERIAL_BAUD = 115200;

static String commandBuffer;
static unsigned long lastHeartbeat = 0;
static bool ledOn = false;

static void beep(int freq, int durationMs) {
  tone(BUZZER_PIN, freq, durationMs);
}

static void ledSet(bool on) {
  ledOn = on;
  digitalWrite(NEOPIXEL_PIN, on ? HIGH : LOW);
}

static void printBanner() {
  Serial.println();
  Serial.println("========================================");
  Serial.println("MycoBrain Side-A Recovery Firmware");
  Serial.println("========================================");
  Serial.println("Commands:");
  Serial.println("  ping");
  Serial.println("  help");
  Serial.println("  status");
  Serial.println("  coin | bump | power | 1up | morgio");
  Serial.println("  led on");
  Serial.println("  led off");
  Serial.println("  reboot");
  Serial.println("Ready!");
  Serial.flush();
}

static void sendStatus() {
  Serial.print("OK: status uptime_ms=");
  Serial.print(millis());
  Serial.print(" led=");
  Serial.println(ledOn ? "on" : "off");
}

static void handleCommand(String cmd) {
  cmd.trim();
  cmd.toLowerCase();

  if (cmd == "ping") {
    Serial.println("OK: ping");
  } else if (cmd == "help") {
    Serial.println("OK: commands ping help status coin bump power 1up morgio led on led off reboot");
  } else if (cmd == "status") {
    sendStatus();
  } else if (cmd == "coin") {
    beep(800, 100); delay(120); beep(1000, 100);
    Serial.println("OK: coin");
  } else if (cmd == "bump") {
    beep(200, 60);
    Serial.println("OK: bump");
  } else if (cmd == "power") {
    beep(600, 180);
    Serial.println("OK: power");
  } else if (cmd == "1up") {
    beep(523, 120); delay(130); beep(659, 120); delay(130); beep(784, 150);
    Serial.println("OK: 1up");
  } else if (cmd == "morgio") {
    beep(440, 100); delay(110); beep(554, 100); delay(110); beep(659, 180);
    Serial.println("OK: morgio");
  } else if (cmd == "led on") {
    ledSet(true);
    Serial.println("OK: led on");
  } else if (cmd == "led off") {
    ledSet(false);
    Serial.println("OK: led off");
  } else if (cmd == "reboot") {
    Serial.println("OK: rebooting");
    Serial.flush();
    delay(250);
    ESP.restart();
  } else if (cmd.length() > 0) {
    Serial.print("ERROR: unknown command: ");
    Serial.println(cmd);
  }
  Serial.flush();
}

void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(1200);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  pinMode(NEOPIXEL_PIN, OUTPUT);
  digitalWrite(NEOPIXEL_PIN, LOW);

  printBanner();
  beep(1000, 120);
}

void loop() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      if (commandBuffer.length() > 0) {
        handleCommand(commandBuffer);
        commandBuffer = "";
      }
    } else {
      commandBuffer += c;
      if (commandBuffer.length() > 128) {
        commandBuffer = "";
        Serial.println("ERROR: command too long");
      }
    }
  }

  if (millis() - lastHeartbeat >= 5000) {
    lastHeartbeat = millis();
    Serial.print("OK: heartbeat uptime_ms=");
    Serial.println(lastHeartbeat);
    Serial.flush();
  }

  delay(10);
}
