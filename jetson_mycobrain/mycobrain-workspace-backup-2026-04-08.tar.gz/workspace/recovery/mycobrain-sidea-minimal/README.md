# MycoBrain Side-A Recovery Firmware

Purpose: get the attached ESP32-S3 back to a known-good, non-crashing state before sensor-day bring-up.

What this firmware proves:
- USB serial is stable
- remote flashing works without button presses
- simple CLI works
- buzzer path works
- LED path works
- reboot path works

Commands:
- ping
- help
- status
- coin
- bump
- power
- 1up
- morgio
- led on
- led off
- reboot

Flash:
```bash
cd /home/jetson/.openclaw/workspace/recovery/mycobrain-sidea-minimal
~/.local/bin/pio run -e esp32-s3-devkitc-1 -t upload --upload-port /dev/ttyACM0
```
