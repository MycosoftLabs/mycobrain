# Reconnect to Jetson After Reboot

Save this somewhere on your Windows desktop before restarting.

## 1. Restart Windows

Just hit restart. Docker Desktop will finish installing.

## 2. After reboot — verify Docker

Open PowerShell:

```powershell
docker --version
```

If it shows a version, Docker is ready. If not, open Docker Desktop from Start menu and wait for it to initialize.

## 3. Reconnect to Jetson in Cursor

Cursor should reopen automatically with the SSH workspace. If not:

1. Open Cursor
2. Press `Ctrl+Shift+P` → type `Remote-SSH: Connect to Host`
3. Select `jetson_` (or whatever your SSH config calls it)
4. It will reconnect to `/home/jetson/.openclaw/workspace`

If SSH fails, check that the Jetson is still on and reachable:

```powershell
ping <JETSON_IP>
ssh jetson@<JETSON_IP>
```

## 4. Resume — set up the MQTT broker

Open the `recovery/mqtt-broker/` folder you copied to your Windows machine and follow `SETUP.md` (or give the prompt to your Claude Code agent).

## 5. After broker is running — report back to Jetson agent

In the Cursor chat on the Jetson workspace, paste:

- Broker IP (your Windows machine's LAN IP)
- Port: 1883
- Username: mycobrain
- Password: whatever you set

The Jetson agent will wire up the publisher to connect.

## Quick reference — where things are

| What | Where |
|------|-------|
| Jetson workspace | `/home/jetson/.openclaw/workspace` (via SSH) |
| MQTT broker setup files | `recovery/mqtt-broker/` (copy to Windows) |
| Session notes | `memory/2026-04-03.md` (on Jetson) |
| Publisher code | `tools/mycobrain-publisher/publisher.js` (on Jetson) |
| Telemetry hub | `tools/mycobrain-telemetry-hub/hub.js` (on Jetson) |
| Operator UI | `http://<JETSON_IP>:8787` (browser) |
