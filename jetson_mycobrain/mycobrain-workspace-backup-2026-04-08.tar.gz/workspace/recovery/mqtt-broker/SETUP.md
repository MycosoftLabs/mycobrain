# MycoBrain MQTT Broker — Docker Setup Guide

## Context

This folder runs a Mosquitto MQTT broker in Docker. It receives telemetry from MycoBrain ESP32 + Jetson edge nodes.

- **Topic pattern:** `mycobrain/<device_id>/telemetry`
- **Payload:** JSON (normalized telemetry schema v1)
- **Consumer:** The Jetson publisher connects via `MYCOBRAIN_MQTT_URL=mqtt://<BROKER_IP>:1883`
- **Security:** Password auth over plain TCP on LAN. TLS deferred.

This same folder works on any machine with Docker: your Windows workstation for testing, then a Linux production server later. Just copy the folder, run the commands, swap the IP.

---

## Step 0 — Prerequisites (Windows 11)

Docker Desktop must be installed with the WSL2 backend.

**Check if Docker is already running:**

```powershell
docker --version
docker compose version
```

If both return versions, skip to Step 1.

**If Docker is not installed:**

```powershell
winget install Docker.DockerDesktop
```

Then restart your machine. After restart, open Docker Desktop and let it finish initializing. Full install guide: https://docs.docker.com/desktop/setup/install/windows-install/

**Verify after install:**

```powershell
docker run --rm hello-world
```

If you see "Hello from Docker!" you're good.

---

## Step 1 — Start the broker

Open a terminal (PowerShell, CMD, or WSL) and `cd` into this folder:

```powershell
cd path\to\mqtt-broker
```

Start it:

```powershell
docker compose up -d
```

Verify it's running:

```powershell
docker ps --filter name=mycobrain-mqtt
```

You should see `mycobrain-mqtt` with status `Up`. It will exit with an error about the missing password file — that's expected, we create it next.

---

## Step 2 — Create the mycobrain user

Pick a password and run this (replace `YOUR_PASSWORD` with your actual password):

```powershell
docker exec mycobrain-mqtt mosquitto_passwd -c -b /mosquitto/config/passwd mycobrain YOUR_PASSWORD
```

This creates the password file non-interactively. No prompts.

To add more users later (without `-c`, which would overwrite):

```powershell
docker exec mycobrain-mqtt mosquitto_passwd -b /mosquitto/config/passwd anotheruser THEIR_PASSWORD
```

---

## Step 3 — Restart to load the password file

```powershell
docker compose restart
```

Check logs to confirm it started cleanly:

```powershell
docker logs mycobrain-mqtt --tail 20
```

You should see lines like `mosquitto version 2.x.x running` and `Opening ipv4 listen socket on port 1883`. No errors about the password file.

---

## Step 4 — Local smoke test

**Subscribe** (runs in foreground, ctrl+C to stop):

```powershell
docker exec mycobrain-mqtt mosquitto_sub -h 127.0.0.1 -p 1883 -u mycobrain -P "YOUR_PASSWORD" -t "mycobrain/#" -v
```

**In a second terminal, publish a test message:**

```powershell
docker exec mycobrain-mqtt mosquitto_pub -h 127.0.0.1 -p 1883 -u mycobrain -P "YOUR_PASSWORD" -t "mycobrain/test/telemetry" -m "{\"ok\":true,\"source\":\"local-docker-test\"}"
```

The subscriber terminal should print:

```
mycobrain/test/telemetry {"ok":true,"source":"local-docker-test"}
```

If it does, the broker works. Ctrl+C the subscriber.

---

## Step 5 — Find your LAN IP

**PowerShell:**

```powershell
Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notlike "*Loopback*" -and $_.PrefixOrigin -eq "Dhcp" } | Select-Object IPAddress, InterfaceAlias
```

Or simply:

```powershell
ipconfig
```

Look for your main adapter's IPv4 address (e.g. `192.168.1.42`).

---

## Step 6 — Windows Firewall

Docker Desktop usually handles port forwarding, but if the Jetson can't connect, allow port 1883 through Windows Firewall:

```powershell
New-NetFirewallRule -DisplayName "MQTT Broker" -Direction Inbound -Protocol TCP -LocalPort 1883 -Action Allow
```

---

## Step 7 — Test from the Jetson

SSH into the Jetson (or tell the Jetson agent to run this):

```bash
# Install mosquitto-clients if not present
sudo apt install -y mosquitto-clients

# Publish a test message to your workstation broker
mosquitto_pub -h BROKER_IP -p 1883 -u mycobrain -P 'YOUR_PASSWORD' -t 'mycobrain/test/telemetry' -m '{"ok":true,"source":"jetson-remote-test"}'
```

On your workstation, if you still have the subscriber running from Step 4, you'll see the message arrive.

If it doesn't connect, check:
- Is the broker running? (`docker ps`)
- Is port 1883 open? (Step 6)
- Can the Jetson reach the workstation IP? (`ping BROKER_IP` from the Jetson)
- Are the Jetson and workstation on the same LAN / VLAN?

---

## Step 8 — Hand back to the Jetson agent

Report these to the Jetson agent (or paste into the chat):

1. **Broker IP:** (from Step 5, e.g. `192.168.1.42`)
2. **Port:** `1883`
3. **Username:** `mycobrain`
4. **Password:** (what you set in Step 2)
5. **Remote test passed?** yes/no

The Jetson agent will then restart the publisher with:

```bash
MYCOBRAIN_MQTT_URL=mqtt://BROKER_IP:1883 MYCOBRAIN_MQTT_USERNAME=mycobrain MYCOBRAIN_MQTT_PASSWORD=YOUR_PASSWORD node publisher.js
```

---

## Step 9 — Redeploy to production server

When ready to move this to your Proxmox/Ubuntu server:

1. Copy this entire `mqtt-broker/` folder to the server
2. SSH into the server
3. Run the same steps:

```bash
cd mqtt-broker
docker compose up -d
docker exec mycobrain-mqtt mosquitto_passwd -c -b /mosquitto/config/passwd mycobrain YOUR_PASSWORD
docker compose restart
docker logs mycobrain-mqtt --tail 20
```

4. Open the firewall on the server:

```bash
sudo ufw allow 1883/tcp
```

5. Update the Jetson publisher to point at the server's IP instead of your workstation.

Same container, same config, new IP. Done.

---

## Stopping / Cleaning up

Stop the broker:

```powershell
docker compose down
```

Stop and remove all data (start fresh):

```powershell
docker compose down -v
rm config/passwd
```

---

## Files in this folder

```
mqtt-broker/
├── docker-compose.yml    # Docker Compose service definition
├── config/
│   └── mosquitto.conf    # Broker configuration
├── data/                 # Persistent message store (auto-populated)
├── log/                  # Broker logs (auto-populated)
└── SETUP.md              # This file
```
