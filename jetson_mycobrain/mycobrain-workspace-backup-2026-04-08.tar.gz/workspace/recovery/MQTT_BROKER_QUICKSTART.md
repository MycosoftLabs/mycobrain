# MycoBrain MQTT Broker — Copy-Paste Quickstart

SSH into your fresh Ubuntu VM and run these blocks in order.

---

## 1. Install

```bash
sudo apt update && sudo apt upgrade -y && sudo apt install -y mosquitto mosquitto-clients ufw
```

## 2. Write config

```bash
sudo tee /etc/mosquitto/conf.d/mycobrain.conf > /dev/null << 'EOF'
persistence true
persistence_location /var/lib/mosquitto/
log_dest file /var/log/mosquitto/mosquitto.log
log_dest stdout

listener 1883
allow_anonymous false
password_file /etc/mosquitto/passwd
EOF
```

## 3. Create the mycobrain user (will prompt for password — remember it)

```bash
sudo mosquitto_passwd -c /etc/mosquitto/passwd mycobrain
```

## 4. Enable, restart, verify

```bash
sudo systemctl enable mosquitto
sudo systemctl restart mosquitto
sudo systemctl status mosquitto --no-pager
ss -ltnp | grep 1883
```

You should see `LISTEN` on port 1883.

## 5. Firewall

```bash
sudo ufw allow 22/tcp
sudo ufw allow 1883/tcp
sudo ufw --force enable
sudo ufw status
```

## 6. Local test (on the VM itself)

Open two terminals (or use `&` / `tmux`).

**Terminal 1 — subscriber:**

```bash
mosquitto_sub -h 127.0.0.1 -p 1883 -u mycobrain -P 'YOUR_PASSWORD' -t 'mycobrain/#' -v
```

**Terminal 2 — publisher:**

```bash
mosquitto_pub -h 127.0.0.1 -p 1883 -u mycobrain -P 'YOUR_PASSWORD' -t 'mycobrain/test/telemetry' -m '{"ok":true,"source":"vm-local-test"}'
```

Terminal 1 should print the message. If it does, the broker works.

## 7. Get your VM's IP

```bash
ip -4 addr show | grep 'inet ' | grep -v 127.0.0.1
```

Note the IP (e.g. `192.168.1.50`).

## 8. Done — hand these back

1. **Broker IP:** (from step 7)
2. **Port:** 1883
3. **Username:** mycobrain
4. **Password:** (what you set in step 3)
5. **Local test passed?** yes/no

I'll handle the Jetson side from there.
