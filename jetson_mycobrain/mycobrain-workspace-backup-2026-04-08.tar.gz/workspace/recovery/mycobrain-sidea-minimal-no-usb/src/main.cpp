#include <Arduino.h>

void setup() {
  Serial.begin(115200);
  delay(1500);
  Serial.println("BOOT: recovery-no-usb-cdc ready");
  Serial.flush();
}

void loop() {
  static unsigned long last = 0;
  if (millis() - last > 3000) {
    last = millis();
    Serial.print("OK: heartbeat ms=");
    Serial.println(last);
    Serial.flush();
  }
  delay(20);
}
