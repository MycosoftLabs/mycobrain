const fs = require('fs');
const path = require('path');
const http = require('http');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

const SERIAL_PORT = process.env.MYCOBRAIN_SERIAL_PORT || '/dev/ttyACM0';
const BAUD = 115200;
const PORT = process.env.MYCOBRAIN_HUB_PORT || 8788;
const STATE_PATH = process.env.MYCOBRAIN_HUB_STATE || path.join(__dirname, 'state', 'latest-telemetry.json');

fs.mkdirSync(path.dirname(STATE_PATH), { recursive: true });

let serialConnected = false;
let lastError = null;
let lastHeartbeat = null;
let lastLines = [];
let lastScan = { addresses: [], count: 0, ts: null };
let sensorSlots = {};
let lastSensorReading = null;

function pushLine(line) {
  const entry = { ts: new Date().toISOString(), line };
  lastLines.push(entry);
  if (lastLines.length > 300) lastLines = lastLines.slice(-300);
  if (line.includes('heartbeat')) lastHeartbeat = entry.ts;

  if (line.startsWith('I2C: found 0x')) {
    const m = line.match(/0x([0-9A-Fa-f]{2})/);
    if (m) {
      const addr = '0x' + m[1].toUpperCase();
      if (!lastScan.addresses.includes(addr)) lastScan.addresses.push(addr);
    }
  }
  if (line.startsWith('OK: scan begin')) {
    lastScan = { addresses: [], count: 0, ts: entry.ts };
  }
  if (line.startsWith('OK: scan count=')) {
    const m = line.match(/count=(\d+)/);
    if (m) lastScan.count = Number(m[1]);
    lastScan.ts = entry.ts;
  }

  if (line.startsWith('{')) {
    try {
      const parsed = JSON.parse(line);
      const hasEnvData = parsed.temperature_c !== undefined || parsed.ambient_temperature_c !== undefined || parsed.humidity_pct !== undefined || parsed.pressure_hpa !== undefined || parsed.gas_ohm !== undefined || parsed.gas_resistance_ohm !== undefined;
      if ((parsed.type === 'sensor' || parsed.type === 'telemetry') && hasEnvData) {
        const reading = { ...parsed, ts: entry.ts };
        const slot = parsed.sensor_slot || 'amb';
        sensorSlots[slot] = reading;
        lastSensorReading = reading;
        fs.writeFileSync(STATE_PATH, JSON.stringify({ slots: sensorSlots, latest: lastSensorReading }, null, 2));
      }
    } catch (err) {
      lastError = err.message;
    }
  }
}

const serial = new SerialPort({ path: SERIAL_PORT, baudRate: BAUD, autoOpen: false });
serial.open((err) => {
  if (err) {
    serialConnected = false;
    lastError = err.message;
    return;
  }
  serialConnected = true;
  lastError = null;
});

const parser = serial.pipe(new ReadlineParser({ delimiter: '\n' }));
parser.on('data', (line) => pushLine(String(line).trimEnd()));
serial.on('error', (err) => {
  serialConnected = false;
  lastError = err.message;
});
serial.on('close', () => {
  serialConnected = false;
});

function sendCommand(cmd, settleMs = 1200) {
  return new Promise((resolve) => {
    if (!serialConnected) return resolve({ ok: false, error: 'serial not connected' });
    const startIdx = lastLines.length;
    serial.write(cmd + '\n', (err) => {
      if (err) return resolve({ ok: false, error: err.message });
      setTimeout(() => {
        resolve({ ok: true, cmd, lines: lastLines.slice(startIdx) });
      }, settleMs);
    });
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, serialConnected, lastError }));
  }
  if (req.method === 'GET' && req.url === '/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, serialPort: SERIAL_PORT, serialConnected, lastHeartbeat, lastError, lastScan, lastSensorReading, lastLines: lastLines.slice(-40) }));
  }
  if (req.method === 'GET' && req.url === '/sensor') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, detected: !!(lastSensorReading && lastSensorReading.present), scan: lastScan, reading: lastSensorReading, slots: sensorSlots }));
  }
  if (req.method === 'GET' && req.url === '/latest') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, latest: lastSensorReading, slots: sensorSlots }));
  }
  if (req.method === 'POST' && req.url === '/cmd') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      try {
        const parsed = JSON.parse(body || '{}');
        const cmd = String(parsed.cmd || '').trim();
        if (!cmd) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ ok: false, error: 'missing cmd' }));
        }
        const result = await sendCommand(cmd);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(result));
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ ok: false, error: err.message }));
      }
    });
    return;
  }
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: false, error: 'not found' }));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`MycoBrain telemetry hub listening on http://0.0.0.0:${PORT}`);
});
