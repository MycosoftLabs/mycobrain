const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const mqtt = require('mqtt');

const HUB_BASE = process.env.MYCOBRAIN_HUB_BASE || 'http://127.0.0.1:8788';
const PORT = process.env.MYCOBRAIN_PUBLISHER_PORT || 8789;
const OUTBOX_DIR = process.env.MYCOBRAIN_PUBLISHER_OUTBOX_DIR || path.join(__dirname, 'outbox');
const LATEST_PATH = path.join(OUTBOX_DIR, 'latest-publish.json');
const QUEUE_PATH = path.join(OUTBOX_DIR, 'queue.json');
const DELIVERY_STATE_PATH = path.join(OUTBOX_DIR, 'delivery-state.json');
const MAX_QUEUE = Number(process.env.MYCOBRAIN_PUBLISHER_MAX_QUEUE || 200);
const CONFIG_VERSION = process.env.MYCOBRAIN_CONFIG_VERSION || 'v0-local-default';

const UPSTREAM_URL = process.env.MYCOBRAIN_UPSTREAM_URL || '';
const UPSTREAM_TOKEN = process.env.MYCOBRAIN_UPSTREAM_TOKEN || '';
const UPSTREAM_TIMEOUT_MS = Number(process.env.MYCOBRAIN_UPSTREAM_TIMEOUT_MS || 10000);
const DELIVERY_INTERVAL_MS = Number(process.env.MYCOBRAIN_DELIVERY_INTERVAL_MS || 5000);
const DELIVERY_BATCH_SIZE = Number(process.env.MYCOBRAIN_DELIVERY_BATCH_SIZE || 10);
const BACKOFF_BASE_MS = 2000;
const BACKOFF_MAX_MS = 120000;
const MAX_DELIVERY_RETRIES = 10;

const MQTT_URL = process.env.MYCOBRAIN_MQTT_URL || '';
const MQTT_USERNAME = process.env.MYCOBRAIN_MQTT_USERNAME || '';
const MQTT_PASSWORD = process.env.MYCOBRAIN_MQTT_PASSWORD || '';
const MQTT_TOPIC_PREFIX = process.env.MYCOBRAIN_MQTT_TOPIC_PREFIX || 'mycobrain';
const MQTT_QOS = Number(process.env.MYCOBRAIN_MQTT_QOS || 1);

fs.mkdirSync(OUTBOX_DIR, { recursive: true });

let latestPublish = null;
let queue = [];
let lastFetchAt = null;
let lastError = null;
let sequence = 0;

let delivery = {
  enabled: !!UPSTREAM_URL,
  lastDeliveredSeq: 0,
  consecutiveFailures: 0,
  totalDelivered: 0,
  totalFailed: 0,
  lastDeliveryAt: null,
  lastDeliveryError: null,
  backoffUntil: null,
};

let mqttState = {
  enabled: !!MQTT_URL,
  connected: false,
  totalPublished: 0,
  totalErrors: 0,
  lastPublishAt: null,
  lastError: null,
};
let mqttClient = null;

try {
  if (fs.existsSync(QUEUE_PATH)) {
    queue = JSON.parse(fs.readFileSync(QUEUE_PATH, 'utf8'));
    if (!Array.isArray(queue)) queue = [];
  }
} catch (err) {
  queue = [];
}

try {
  if (fs.existsSync(DELIVERY_STATE_PATH)) {
    const saved = JSON.parse(fs.readFileSync(DELIVERY_STATE_PATH, 'utf8'));
    delivery.lastDeliveredSeq = saved.lastDeliveredSeq || 0;
    delivery.totalDelivered = saved.totalDelivered || 0;
    delivery.totalFailed = saved.totalFailed || 0;
  }
} catch (err) { /* start fresh */ }

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const req = http.request({ hostname: u.hostname, port: u.port, path: u.pathname, method: 'GET' }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data || '{}')); }
        catch (err) { reject(err); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

function postUpstream(payload) {
  return new Promise((resolve, reject) => {
    const u = new URL(UPSTREAM_URL);
    const transport = u.protocol === 'https:' ? https : http;
    const body = JSON.stringify(payload);
    const headers = {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(body),
    };
    if (UPSTREAM_TOKEN) {
      headers['Authorization'] = `Bearer ${UPSTREAM_TOKEN}`;
    }
    const req = transport.request({
      hostname: u.hostname,
      port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname + u.search,
      method: 'POST',
      headers,
      timeout: UPSTREAM_TIMEOUT_MS,
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve({ status: res.statusCode, body: data });
        } else {
          reject(new Error(`upstream ${res.statusCode}: ${data.slice(0, 200)}`));
        }
      });
    });
    req.on('timeout', () => { req.destroy(); reject(new Error('upstream timeout')); });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function normalize(reading, fetchedAt) {
  sequence += 1;

  const isBsec2 = reading.ambient_temperature_c !== undefined;
  const sensorType = isBsec2 ? 'bme688_bsec2' : 'bme680_class_env';

  const readings = {
    // v1 backward-compat: map to canonical names
    temperature_c: reading.temperature_c ?? reading.ambient_temperature_c ?? null,
    humidity_pct: reading.humidity_pct ?? reading.ambient_humidity_pct ?? null,
    pressure_hpa: reading.pressure_hpa ?? null,
    gas_ohm: reading.gas_ohm ?? reading.gas_resistance_ohm ?? null,
  };

  if (isBsec2) {
    // BSEC2 compensated environmental
    readings.temperature_c_comp = reading.temperature_c_comp ?? null;
    readings.temperature_f_comp = reading.temperature_f_comp ?? null;
    readings.humidity_pct_comp = reading.humidity_pct_comp ?? null;
    readings.gas_resistance_ohm_comp = reading.gas_resistance_ohm_comp ?? null;

    // Ambient (raw)
    readings.ambient_temperature_c = reading.ambient_temperature_c ?? null;
    readings.ambient_temperature_f = reading.ambient_temperature_f ?? null;
    readings.ambient_humidity_pct = reading.ambient_humidity_pct ?? null;

    // IAQ / gas analysis
    readings.iaq = reading.iaq ?? null;
    readings.iaq_static = reading.iaq_static ?? null;
    readings.iaq_accuracy = reading.iaq_accuracy ?? null;
    readings.eco2_ppm = reading.eco2_ppm ?? null;
    readings.bvoc_ppm = reading.bvoc_ppm ?? null;
    readings.gas_percentage = reading.gas_percentage ?? null;

    // Raw gas
    readings.gas_resistance_ohm = reading.gas_resistance_ohm ?? null;

    // Sensor status
    readings.stabilization_status = reading.stabilization_status ?? null;
    readings.run_in_status = reading.run_in_status ?? null;
    readings.output_accuracy = reading.output_accuracy ?? null;
    readings.bsec_status_code = reading.bsec_status_code ?? null;
    readings.bme68x_status_code = reading.bme68x_status_code ?? null;

    // Gas estimates
    readings.gas_estimate_1 = reading.gas_estimate_1 ?? null;
    readings.gas_estimate_2 = reading.gas_estimate_2 ?? null;
    readings.gas_estimate_3 = reading.gas_estimate_3 ?? null;
    readings.gas_estimate_4 = reading.gas_estimate_4 ?? null;
    readings.gas_estimate_accuracy = reading.gas_estimate_accuracy ?? null;

    // Raw BME68x flags
    readings.new_data = reading.new_data ?? null;
    readings.measuring = reading.measuring ?? null;
    readings.gas_measuring = reading.gas_measuring ?? null;
    readings.gas_meas_index = reading.gas_meas_index ?? null;
    readings.sub_meas_index = reading.sub_meas_index ?? null;
    readings.gas_valid = reading.gas_valid ?? null;
    readings.heat_stable = reading.heat_stable ?? null;
    readings.chip_id = reading.chip_id ?? null;
    readings.variant_id = reading.variant_id ?? null;

    // Device metadata
    readings.temp_offset_c = reading.temp_offset_c ?? null;
    readings.sample_rate_mode = reading.sample_rate_mode ?? null;
    readings.heater_profile_id = reading.heater_profile_id ?? null;
    readings.model_type = reading.model_type ?? null;
    readings.class_count = reading.class_count ?? null;
    readings.uptime_s = reading.uptime_s ?? null;
    readings.boot_count = reading.boot_count ?? null;
  }

  return {
    schema_version: isBsec2 ? '2.0.0' : '1.0.0',
    type: 'telemetry',
    device_id: reading.device_id || 'unknown-device',
    node_id: reading.node_id || reading.device_id || 'unknown-device',
    role: reading.role || 'unknown-role',
    sensor_slot: reading.sensor_slot || 'unknown-slot',
    sensor_type: sensorType,
    address: reading.address || 'unknown',
    fw_version: reading.fw_version || 'unknown-fw',
    config_version: reading.config_version || CONFIG_VERSION,
    bsec_version: reading.bsec_version || null,
    sequence,
    present: !!reading.present,
    valid: !!reading.valid,
    timestamp: reading.ts || fetchedAt,
    ts_ms: reading.ts_ms ?? null,
    location: reading.location || { lat: null, lon: null, source: 'na' },
    readings,
    quality_flags: [],
    threshold_state: 'normal',
    ingestion_source: 'serial'
  };
}

function persist() {
  fs.writeFileSync(LATEST_PATH, JSON.stringify(latestPublish, null, 2));
  fs.writeFileSync(QUEUE_PATH, JSON.stringify(queue, null, 2));
}

function persistDeliveryState() {
  fs.writeFileSync(DELIVERY_STATE_PATH, JSON.stringify({
    lastDeliveredSeq: delivery.lastDeliveredSeq,
    totalDelivered: delivery.totalDelivered,
    totalFailed: delivery.totalFailed,
    updatedAt: new Date().toISOString(),
  }, null, 2));
}

function mqttPublish(normalized) {
  if (!mqttState.enabled || !mqttClient || !mqttState.connected) return;
  const deviceId = normalized.device_id || 'unknown-device';
  const topic = `${MQTT_TOPIC_PREFIX}/${deviceId}/telemetry`;
  const payload = JSON.stringify(normalized);
  mqttClient.publish(topic, payload, { qos: MQTT_QOS }, (err) => {
    if (err) {
      mqttState.totalErrors += 1;
      mqttState.lastError = err.message;
      console.error(`[mqtt] publish error on ${topic}: ${err.message}`);
    } else {
      mqttState.totalPublished += 1;
      mqttState.lastPublishAt = new Date().toISOString();
    }
  });
}

function initMqtt() {
  if (!MQTT_URL) return;
  const opts = {
    reconnectPeriod: 5000,
    connectTimeout: 10000,
  };
  if (MQTT_USERNAME) opts.username = MQTT_USERNAME;
  if (MQTT_PASSWORD) opts.password = MQTT_PASSWORD;

  mqttClient = mqtt.connect(MQTT_URL, opts);

  mqttClient.on('connect', () => {
    mqttState.connected = true;
    mqttState.lastError = null;
    console.log(`[mqtt] connected to ${MQTT_URL}`);
  });
  mqttClient.on('reconnect', () => {
    console.log('[mqtt] reconnecting...');
  });
  mqttClient.on('close', () => {
    mqttState.connected = false;
  });
  mqttClient.on('error', (err) => {
    mqttState.lastError = err.message;
    console.error(`[mqtt] error: ${err.message}`);
  });
  mqttClient.on('offline', () => {
    mqttState.connected = false;
  });
}

async function refreshFromHub() {
  try {
    const data = await fetchJson(`${HUB_BASE}/latest`);
    lastFetchAt = new Date().toISOString();

    const readings = [];
    if (data && data.slots && typeof data.slots === 'object') {
      for (const slot of Object.values(data.slots)) {
        if (slot && slot.present && slot.valid) readings.push(slot);
      }
    }
    if (readings.length === 0 && data && data.latest) {
      readings.push(data.latest);
    }

    for (const reading of readings) {
      const normalized = normalize(reading, lastFetchAt);
      latestPublish = {
        publish_type: 'telemetry_publish_candidate',
        upstream_ready: true,
        source: 'mycobrain-telemetry-hub',
        fetched_at: lastFetchAt,
        payload: normalized
      };
      queue.push(latestPublish);
      mqttPublish(normalized);
    }

    if (queue.length > MAX_QUEUE) {
      queue = queue.slice(queue.length - MAX_QUEUE);
    }
    if (readings.length > 0) {
      persist();
      lastError = null;
    }
  } catch (err) {
    lastError = err.message;
  }
}

async function deliverUpstream() {
  if (!delivery.enabled) return;

  if (delivery.backoffUntil && Date.now() < delivery.backoffUntil) return;

  const pending = queue.filter(
    item => item.payload && item.payload.sequence > delivery.lastDeliveredSeq
  );
  if (pending.length === 0) return;

  const batch = pending.slice(0, DELIVERY_BATCH_SIZE);

  for (const item of batch) {
    try {
      await postUpstream(item.payload);
      delivery.lastDeliveredSeq = item.payload.sequence;
      delivery.totalDelivered += 1;
      delivery.lastDeliveryAt = new Date().toISOString();
      delivery.lastDeliveryError = null;
      delivery.consecutiveFailures = 0;
      delivery.backoffUntil = null;
    } catch (err) {
      delivery.consecutiveFailures += 1;
      delivery.totalFailed += 1;
      delivery.lastDeliveryError = err.message;
      const backoff = Math.min(
        BACKOFF_BASE_MS * Math.pow(2, delivery.consecutiveFailures - 1),
        BACKOFF_MAX_MS
      );
      delivery.backoffUntil = Date.now() + backoff;
      console.error(`[delivery] fail #${delivery.consecutiveFailures}, backoff ${backoff}ms: ${err.message}`);
      if (delivery.consecutiveFailures >= MAX_DELIVERY_RETRIES) {
        console.error(`[delivery] max retries (${MAX_DELIVERY_RETRIES}) reached, pausing until next success window`);
      }
      break;
    }
  }
  persistDeliveryState();
}

setInterval(refreshFromHub, 2000);
refreshFromHub();

if (mqttState.enabled) {
  initMqtt();
  console.log(`[mqtt] MQTT enabled -> ${MQTT_URL}`);
} else {
  console.log('[mqtt] MQTT disabled (set MYCOBRAIN_MQTT_URL to enable)');
}

if (delivery.enabled) {
  console.log(`[delivery] HTTP upstream enabled -> ${UPSTREAM_URL}`);
  setInterval(deliverUpstream, DELIVERY_INTERVAL_MS);
  deliverUpstream();
} else {
  console.log('[delivery] HTTP upstream disabled (set MYCOBRAIN_UPSTREAM_URL to enable)');
}

function mqttStatus() {
  return {
    enabled: mqttState.enabled,
    brokerUrl: MQTT_URL || null,
    connected: mqttState.connected,
    totalPublished: mqttState.totalPublished,
    totalErrors: mqttState.totalErrors,
    lastPublishAt: mqttState.lastPublishAt,
    lastError: mqttState.lastError,
  };
}

function deliveryStatus() {
  return {
    http: {
      enabled: delivery.enabled,
      upstreamUrl: UPSTREAM_URL || null,
      lastDeliveredSeq: delivery.lastDeliveredSeq,
      consecutiveFailures: delivery.consecutiveFailures,
      totalDelivered: delivery.totalDelivered,
      totalFailed: delivery.totalFailed,
      lastDeliveryAt: delivery.lastDeliveryAt,
      lastDeliveryError: delivery.lastDeliveryError,
      backingOff: delivery.backoffUntil ? Date.now() < delivery.backoffUntil : false,
      pendingCount: queue.filter(i => i.payload && i.payload.sequence > delivery.lastDeliveredSeq).length,
    },
    mqtt: mqttStatus(),
  };
}

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, lastFetchAt, lastError, queueDepth: queue.length, delivery: deliveryStatus() }));
  }
  if (req.method === 'GET' && req.url === '/latest') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, latestPublish, lastFetchAt, lastError, queueDepth: queue.length }));
  }
  if (req.method === 'GET' && req.url === '/queue') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, queueDepth: queue.length, queue }));
  }
  if (req.method === 'GET' && req.url === '/delivery') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, ...deliveryStatus() }));
  }
  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, message: 'MycoBrain publisher', latestPublish, lastFetchAt, lastError, queueDepth: queue.length, delivery: deliveryStatus() }));
  }
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: false, error: 'not found' }));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`MycoBrain publisher listening on http://0.0.0.0:${PORT}`);
});

function shutdown() {
  console.log('[publisher] shutting down...');
  if (mqttClient) mqttClient.end(false, () => console.log('[mqtt] disconnected'));
  server.close();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
