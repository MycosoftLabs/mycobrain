const fs = require('fs');
const path = require('path');
const http = require('http');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

const SERIAL_PORT = process.env.MYCOBRAIN_SERIAL_PORT || '/dev/ttyACM0';
const BAUD = 115200;
const STATE_PATH = process.env.MYCOBRAIN_FORWARDER_STATE || path.join(__dirname, 'state', 'latest-telemetry.json');
const HTTP_PORT = process.env.MYCOBRAIN_FORWARDER_PORT || 8788;

fs.mkdirSync(path.dirname(STATE_PATH), { recursive: true });

let latest = null;
let lastError = null;
let serialConnected = false;

const serial = new SerialPort({ path: SERIAL_PORT, baudRate: BAUD, autoOpen: false });
serial.open((err) => {
  if (err) {
    lastError = err.message;
    serialConnected = false;
    return;
  }
  serialConnected = true;
  lastError = null;
});

const parser = serial.pipe(new ReadlineParser({ delimiter: '\n' }));
parser.on('data', (line) => {
  const trimmed = String(line).trim();
  if (!trimmed.startsWith('{')) return;
  try {
    const parsed = JSON.parse(trimmed);
    if (parsed.type === 'telemetry' && parsed.temperature_c !== undefined) {
      latest = { ...parsed, received_at: new Date().toISOString() };
      fs.writeFileSync(STATE_PATH, JSON.stringify(latest, null, 2));
    }
  } catch (err) {
    lastError = err.message;
  }
});

serial.on('error', (err) => {
  serialConnected = false;
  lastError = err.message;
});
serial.on('close', () => {
  serialConnected = false;
});

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, serialConnected, lastError }));
  }
  if (req.method === 'GET' && req.url === '/latest') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, latest, serialConnected, lastError }));
  }
  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, message: 'MycoBrain forwarder', latest, serialConnected, lastError }));
  }
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: false, error: 'not found' }));
});

server.listen(HTTP_PORT, '0.0.0.0', () => {
  console.log(`MycoBrain forwarder listening on http://0.0.0.0:${HTTP_PORT}`);
});
