# MycoBrain Operator UI

Local Jetson-hosted interface for board control, testing, and diagnostics.

## Start

```bash
cd /home/jetson/.openclaw/workspace/tools/mycobrain-ui
npm install
node server.js
```

Default URL:
- `http://localhost:8787`
- `http://<jetson-lan-ip>:8787`

## Current Features
- board status
- recent serial log
- command buttons for operator firmware
- command result panel

## Notes
This UI talks to the current stable operator/recovery firmware over `/dev/ttyACM0`.
