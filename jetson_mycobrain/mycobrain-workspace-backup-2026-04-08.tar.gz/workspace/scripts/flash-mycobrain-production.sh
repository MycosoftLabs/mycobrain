#!/usr/bin/env bash
set -euo pipefail

PIO_BIN="$HOME/.local/bin/pio"
REPO_ROOT="/home/jetson/.openclaw/workspace/imports/mycobrain-main"

usage() {
  cat <<'EOF'
Usage:
  flash-mycobrain-production.sh sidea mushroom1 /dev/ttyACM0
  flash-mycobrain-production.sh sidea hyphae1 /dev/ttyACM0
  flash-mycobrain-production.sh sideb esp32-s3-devkitc-1 /dev/ttyACM0

Notes:
  - sidea env must be: mushroom1 or hyphae1
  - sideb env should be: esp32-s3-devkitc-1
EOF
}

if [[ $# -ne 3 ]]; then
  usage
  exit 1
fi

BOARD="$1"
ENV_NAME="$2"
PORT="$3"

if [[ ! -x "$PIO_BIN" ]]; then
  echo "PlatformIO not found at $PIO_BIN" >&2
  exit 1
fi

case "$BOARD" in
  sidea)
    PROJECT_DIR="$REPO_ROOT/firmware/MycoBrain_SideA_MDP"
    if [[ "$ENV_NAME" != "mushroom1" && "$ENV_NAME" != "hyphae1" ]]; then
      echo "For sidea, env must be mushroom1 or hyphae1" >&2
      exit 1
    fi
    ;;
  sideb)
    PROJECT_DIR="$REPO_ROOT/firmware/MycoBrain_SideB_MDP"
    if [[ "$ENV_NAME" != "esp32-s3-devkitc-1" ]]; then
      echo "For sideb, env must be esp32-s3-devkitc-1" >&2
      exit 1
    fi
    ;;
  *)
    echo "Board must be sidea or sideb" >&2
    exit 1
    ;;
esac

echo "== MycoBrain Production Flash =="
echo "Board: $BOARD"
echo "Env:   $ENV_NAME"
echo "Port:  $PORT"
echo "Dir:   $PROJECT_DIR"
echo

cd "$PROJECT_DIR"
"$PIO_BIN" run -e "$ENV_NAME"
"$PIO_BIN" run -e "$ENV_NAME" -t upload --upload-port "$PORT"

echo
echo "Flash complete."
